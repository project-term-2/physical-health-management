$(document).ready(function() {
        const config = {
            apiKey: "AIzaSyDb2zqOoWiOBwSSkg1fU0ThcYddPZ-0oPQ",
            authDomain: "physical-health-management.firebaseapp.com",
            databaseURL: "https://physical-health-management-default-rtdb.firebaseio.com",
            projectId: "physical-health-management",
            storageBucket: "physical-health-management.appspot.com",
            messagingSenderId: "1072633341334",
            appId: "1:1072633341334:web:746c76af60e9a877e769b7",
            measurementId: "G-MYKSGW6BLD"
    };    
    firebase.initializeApp(config); //inicializamos firebase
    
    var filaEliminada; //para capturara la fila eliminada
    var filaEditada; //para capturara la fila editada o actualizada

    //creamos constantes para los iconos editar y borrar    
    const iconoEditar = '<svg class="bi bi-pencil-square" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/><path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/></svg>';
    const iconoBorrar = '<svg class="bi bi-trash" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/><path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/></svg>';

    var db = firebase.database();
    var coleccionMenu = db.ref().child("menu");
         
    var dataSet = [];//array para guardar los valores de los campos inputs del form
    var table = $('#tablaMenu').DataTable({
                pageLength : 5,
                lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Todos']],
                data: dataSet,
                columnDefs: [
                    {
                        targets: [0], 
                        visible: false, //ocultamos la columna de ID que es la [0]                        
                    },
                    {
                        targets: -1,        
                        defaultContent: "<div class='wrapper text-center'><div class='btn-group'><button class='btnEditar btn btn-primary' data-toggle='tooltip' title='Editar'>"+iconoEditar+"</button><button class='btnBorrar btn btn-danger' data-toggle='tooltip' title='Borrar'>"+iconoBorrar+"</button></div></div>"
                    }
                ]	   
            });

    coleccionMenu.on("child_added", datos => {        
        dataSet = [datos.key, datos.child("มื้ออาหาร").val(), datos.child("รายการ").val(), datos.child("ปริมาณ").val(), datos.child("จำนวนแคล").val()];
        table.rows.add([dataSet]).draw();
    });
    coleccionMenu.on('child_changed', datos => {           
        dataSet = [datos.key, datos.child("มื้ออาหาร").val(), datos.child("รายการ").val(), datos.child("ปริมาณ").val(), datos.child("จำนวนแคล").val()];
        table.row(filaEditada).data(dataSet).draw();
    });
    coleccionMenu.on("child_removed", function() {
        table.row(filaEliminada.parents('tr')).remove().draw();                     
    });
          
    $('form').submit(function(e){                         
        e.preventDefault();
        let id = $.trim($('#id').val());     
        let มื้ออาหาร = $.trim($('#มื้ออาหาร').val());   
        let รายการ = $.trim($('#รายการ').val());
        let ปริมาณ = $.trim($('#ปริมาณ').val());         
        let จำนวนแคล = $.trim($('#จำนวนแคล').val());                         
        let idFirebase = id;        
        if (idFirebase == ''){                      
            idFirebase = coleccionMenu.push().key;
        };                
        data = {มื้ออาหาร:มื้ออาหาร, รายการ:รายการ, ปริมาณ:ปริมาณ, จำนวนแคล:จำนวนแคล};             
        actualizacionData = {};
        actualizacionData[`/${idFirebase}`] = data;
        coleccionMenu.update(actualizacionData);
        id = '';        
        $("form").trigger("reset");
        $('#modalAltaEdicion').modal('hide');
    });

    //Botones
    $('#btnNuevo').click(function() {
        $('#id').val('');  
        $('#มื้ออาหาร').val('');      
        $('#รายการ').val('');
        $('#ปริมาณ').val('');         
        $('#จำนวนแคล').val('');      
        $("form").trigger("reset");
        $('#modalAltaEdicion').modal('show');
    });        

    $("#tablaMenu").on("click", ".btnEditar", function() {    
        filaEditada = table.row($(this).parents('tr'));           
        let fila = $('#tablaMenu').dataTable().fnGetData($(this).closest('tr'));               
        let id = fila[0];
        console.log(id);
        let มื้ออาหาร = $(this).closest('tr').find('td:eq(0)').text(); 
		let รายการ = $(this).closest('tr').find('td:eq(1)').text(); 
        let ปริมาณ = $(this).closest('tr').find('td:eq(2)').text();        
        let จำนวนแคล = parseInt($(this).closest('tr').find('td:eq(3)').text());        
        $('#id').val(id);
        $('#มื้ออาหาร').val(มื้ออาหาร);        
        $('#รายการ').val(รายการ);
        $('#ปริมาณ').val(ปริมาณ);                
        $('#จำนวนแคล').val(จำนวนแคล);                
        $('#modalAltaEdicion').modal('show');
	});  
  
    $("#tablaMenu").on("click", ".btnBorrar", function() {   
        filaEliminada = $(this);
        Swal.fire({
        title: 'คุณต้องการลบข้อมูลหรือไม่?',
        text: "หากลบแล้วจะไม่สามารถกู้คืนข้อมูลได้!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'แน่ใจ',
        cancelButtonText: 'ย้อนกลับ'
        }).then((result) => {
        if (result.value) {
            let fila = $('#tablaMenu').dataTable().fnGetData($(this).closest('tr'));            
            let id = fila[0];            
            db.ref(`menu/${id}`).remove()
            Swal.fire('ข้อมูลของคุณถูกลบเรียบร้อย', 'Thank you','success')
        }
        })        
	});  

});